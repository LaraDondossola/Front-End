import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
// salva as mensagens, guarda elas
export class AppComponent {
  mensagens: string[] = [];
  novaMensagem: string = '';
  // carregar as mensagens
  constructor() {
    const mensagensSalvas = localStorage.getItem('mensagensSalvas');
    if (mensagensSalvas) {
      this.mensagens = JSON.parse(mensagensSalvas);
    }
  }

  enviarMensagem() {
    if (this.novaMensagem.trim()) {
      this.mensagens.push(this.novaMensagem);
      localStorage.setItem('mensagensSalvas', JSON.stringify(this.mensagens));
      this.novaMensagem = '';
    }
  }
}
// trim verifica os espaços vazios, this faz referência as variáveis e os métodos
