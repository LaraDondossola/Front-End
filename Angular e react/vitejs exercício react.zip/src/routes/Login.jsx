import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

export default function Login() {
  const [nome, setNome] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (nome.trim() !== '') {
      localStorage.setItem('nomeUsuario', nome);
      navigate('/chat');
    }
  };

  return (
    <div className="centralizado">
      <div id="login-container">
        <h2>Digite seu nome:</h2>
        <form onSubmit={handleLogin}>
          <input type="text" placeholder="Nome" value={nome} onChange={(e) => setNome(e.target.value)} required />
          <button type="submit">Entrar</button>
        </form>
      </div>
    </div>
  );
}