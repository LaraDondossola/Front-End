import { useState, useEffect, useRef } from 'react'; // <-- Adicionado useRef
import './Chat.css';

export default function Chat() {
  const nomeUsuario = localStorage.getItem('nomeUsuario');
  const [mensagens, setMensagens] = useState([]);
  const [novaMensagem, setNovaMensagem] = useState('');

  const chatBoxRef = useRef(null); // <-- Adicionado a ref

  useEffect(() => {
    const mensagensSalvas = localStorage.getItem('mensagensSalvas');
    if (mensagensSalvas) {
      setMensagens(JSON.parse(mensagensSalvas));
    }
  }, []);

  // <-- NOVO useEffect para rolagem automática
  useEffect(() => {
    if (chatBoxRef.current) {
      chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight;
    }
  }, [mensagens]); // Dependência: 'mensagens'

  const enviarMensagem = (e) => {
    e.preventDefault();
    if (novaMensagem.trim()) {
      // Mantendo o formato original das mensagens como strings simples para o localStorage
      const novasMensagens = [...mensagens, novaMensagem];
      setMensagens(novasMensagens);
      localStorage.setItem('mensagensSalvas', JSON.stringify(novasMensagens));
      setNovaMensagem('');
    }
  };

  return (
    <div id="tudo">
      <h1 className="titulo">ATENDIMENTO ON-LINE</h1>

      <div id="chat" ref={chatBoxRef}> {/* <-- Ref associada aqui */}
        <div className="bloco_atendente">
          <div className="atendente">
            <strong>Atendente diz: </strong>
          </div>
          <div className="msg_atendente">Olá, {nomeUsuario}</div>
          <div className="atendente">
            <strong>Atendente diz: </strong>
          </div>
          <div className="msg_atendente">Como posso ajudar?</div>
        </div>

        {mensagens.map((msg, index) => (
          <div key={index} className="bloco_requerente">
            <div className="requerente">
              <strong>Requerente diz: </strong>
            </div>
            <div className="msg_requerente">{msg}</div>
          </div>
        ))}
      </div>

      <form id="msg_enviar" onSubmit={enviarMensagem}>
        <input
          type="text"
          id="message"
          placeholder="Digite sua mensagem..."
          value={novaMensagem}
          onChange={(e) => setNovaMensagem(e.target.value)}
        />
        <button type="submit">Enviar</button>
      </form>
    </div>
  );
}